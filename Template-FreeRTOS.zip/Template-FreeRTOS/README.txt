此工程模板是基于2022年ST官方更新的版标准库创建的
目标设备为STM32F407
2022年ST官方更新的标准库下载网址：https://www.st.com/zh/embedded-software/stsw-stm32054.html