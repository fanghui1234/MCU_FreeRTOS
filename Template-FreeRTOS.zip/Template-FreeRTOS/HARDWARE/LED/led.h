#ifndef __LED_H_
#define	__LED_H_

	#include "stm32f4xx.h"
	#include "sys.h"

	
	void LED_Init(void);


#endif
